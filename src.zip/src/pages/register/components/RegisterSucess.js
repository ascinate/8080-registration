import React from "react";

function RegisterSucess(){

    return(
        <>
           <p className="text-center"> Registered for roffle on 22nd on July, 2022. Awaiting result. </p>
        </>
    )
}

export default RegisterSucess;