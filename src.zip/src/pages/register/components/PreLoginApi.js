import EventValue from "./EventValue";
import ButtonRegister from "./ButtonRegister";

const Alldatapre =[

    {
      id:1,
      titel:"Gen 1",
      register:"66",
      allowed:"66",
      winners:"22",
      firstpara:" All registrants will be on the final allowlist.",
      fist1:"FIRST COME",
      last1:"FIRST SERVE",
      nouncheck:"images/vari-checkbox-1043037.png",
      notvaricheck:"",
      registerbtn:"",
      tagevent:"Registered for roffle on 22nd on July, 2022. Awaiting result.",
      colsetext:<EventValue/>,
      registerstatus:""
     
      
    },

    {
        id:2,
        titel:"Gen 2",
        register:"66",
        allowed:"66",
        winners:"22",
        fist1:"",
        last1:"",
        firstpara:" ",
        nouncheck:"images/vari-checkbox-1043037.png",
        notvaricheck:"images/Path-3490.png",
        registerbtn:<ButtonRegister/>,
        tagevent:"",
        colsetext:"",
        registerstatus:"Registered for roffle on 22nd on July, 2022. Awaiting result.",
        
        
    },



]

export default Alldatapre;